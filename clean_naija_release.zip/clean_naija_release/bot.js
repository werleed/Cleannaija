require('dotenv').config();
const { Telegraf, Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');
const twilio = require('./twilio');
const DATA_DIR = path.join(__dirname,'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
const USERS = path.join(DATA_DIR,'users.json');
const WASTE = path.join(DATA_DIR,'waste.json');
const WITHD = path.join(DATA_DIR,'withdrawals.json');
const META = path.join(DATA_DIR,'meta.json');
const COMPS = path.join(DATA_DIR,'complaints.json');
const REF = path.join(DATA_DIR,'referrals.json');
// ensure files
const ensure = (p, init) => { if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify(init, null, 2)); };
ensure(USERS, []); ensure(WASTE, []); ensure(WITHD, []); ensure(META, { rate_per_kg: 120, verification_days:30 }); ensure(COMPS, []); ensure(REF, []);
const read = p => JSON.parse(fs.readFileSync(p,'utf8')||'[]');
const write = (p,d) => fs.writeFileSync(p, JSON.stringify(d, null, 2));
const BOT_TOKEN = process.env.TELEGRAM_TOKEN || '';
const ADMIN = Number(process.env.ADMIN_TELEGRAM_ID || process.env.ADMIN_ID || 0);
if (!BOT_TOKEN) { console.error('Missing TELEGRAM_TOKEN in env'); process.exit(1); }
const bot = new Telegraf(BOT_TOKEN);
// utilities
function findUserByTelegram(id){ return read(USERS).find(u=>u.telegram_id===id); }
function saveOrUpdateUser(user){ const arr = read(USERS); const i = arr.findIndex(x=>x.telegram_id===user.telegram_id); if(i===-1) arr.push(user); else arr[i]=user; write(USERS,arr); }
function verifiedWithin(user){ if(!user || !user.verified_at) return false; const meta = read(META); const days = meta.verification_days||30; const diff = (Date.now() - new Date(user.verified_at).getTime())/(1000*60*60*24); return diff <= days; }
// in-memory flow trackers
const pendingVerify = {}; // tgId -> { phone }
const waitingForWaste = {};
const waitingForWithdrawBank = {};
const waitingForComplaint = {};
// Start flow: ensure verification first
bot.start(async (ctx)=>{
  const tg = ctx.from;
  let user = findUserByTelegram(tg.id);
  if(!user){ user = { telegram_id: tg.id, username: tg.username||'', first_name: tg.first_name||'', phone:null, verified:false, verified_at:null, total_kg:0, balance:0, referrals:0, rank:'Newbie', joined:new Date().toISOString() }; saveOrUpdateUser(user); }
  // if verified recently, show main menu, else start verification prompt
  if(user.verified && verifiedWithin(user)){
    return showMainMenu(ctx, user);
  } else {
    // ask: use Telegram phone or enter number
    await ctx.reply('Welcome to CleanNaijaBot! To continue we need to verify your phone.\nChoose an option:', Markup.keyboard([['Use Telegram Number','Enter Phone Manually']]).oneTime().resize());
  }
});
// helper: main menu
async function showMainMenu(ctx, user){
  await ctx.reply(`Hi ${user.first_name||''}! You are verified. Choose an option:`, Markup.keyboard([['Scan Waste','My Earnings'], ['Withdraw','File Complaint'], ['History','Help']]).resize());
}
// handle contact share
bot.on('contact', async (ctx)=>{
  const contact = ctx.message.contact;
  const tgId = ctx.from.id;
  let user = findUserByTelegram(tgId);
  if(!user){ user = { telegram_id: tgId, username: ctx.from.username||'', first_name: ctx.from.first_name||'', total_kg:0, balance:0 }; }
  user.phone = contact.phone_number;
  user.verified = false;
  saveOrUpdateUser(user);
  // send verify
  const res = await twilio.startVerify(user.phone);
  if(res.success){ pendingVerify[tgId] = { phone: user.phone, ts: Date.now() }; return ctx.reply('OTP sent to ' + user.phone + '. Enter the code here (test mode code: 123456).'); }
  return ctx.reply('Failed to send OTP: ' + (res.error||'unknown'));
});
// manual phone flow
bot.hears(/Enter Phone Manually/i, ctx=> ctx.reply('Please enter your phone number in international format, e.g. +2348090000000:'));
bot.hears(/^\+?[0-9]{7,15}$/, async (ctx)=>{
  const tgId = ctx.from.id; const phone = ctx.message.text.trim();
  let user = findUserByTelegram(tgId); if(!user) user = { telegram_id: tgId, username: ctx.from.username||'', first_name: ctx.from.first_name||'', total_kg:0, balance:0 };
  user.phone = phone; user.verified=false; saveOrUpdateUser(user);
  const res = await twilio.startVerify(phone);
  if(res.success){ pendingVerify[tgId] = { phone, ts:Date.now() }; return ctx.reply('OTP sent to ' + phone + '. Enter the 6-digit code here (test mode 123456).'); }
  return ctx.reply('Failed to start verification: ' + (res.error||'unknown'));
});
bot.hears(/Use Telegram Number/i, async (ctx)=>{
  // try to use contact from Telegram profile - Telegram doesn't expose phone automatically, ask user to share contact
  await ctx.reply('Please press the "Share Contact" button to share your Telegram phone number.', Markup.keyboard([[{ text:'Share Contact', request_contact:true }]]).oneTime().resize());
});
// OTP input handler
bot.hears(/^\d{4,8}$/, async (ctx)=>{
  const code = ctx.message.text.trim(); const tgId = ctx.from.id;
  const pend = pendingVerify[tgId]; if(!pend) return ctx.reply('No pending verification. Use /start to begin.');
  const chk = await twilio.checkVerify(pend.phone, code);
  if(chk.success){
    // mark verified
    let user = findUserByTelegram(tgId); if(!user) user = { telegram_id:tgId, username:ctx.from.username||'', first_name:ctx.from.first_name||'' };
    user.verified = true; user.verified_at = new Date().toISOString(); saveOrUpdateUser(user);
    delete pendingVerify[tgId];
    await ctx.reply('✅ Phone verified successfully!');
    return showMainMenu(ctx, user);
  } else {
    return ctx.reply('OTP invalid: ' + (chk.error||'failed'));
  }
});
// Scan Waste - can accept photo or typed input
bot.hears(/Scan Waste/i, async (ctx)=>{
  const user = findUserByTelegram(ctx.from.id); if(!user || !user.verified) return ctx.reply('You must verify first.');
  waitingForWaste[ctx.from.id] = true;
  return ctx.reply('Send a photo of the waste OR type its name/description. You can also type "estimate" to let the collector estimate weight.');
});
// handle photo
bot.on('photo', async (ctx)=>{
  const tgId = ctx.from.id; if(!waitingForWaste[tgId]) return;
  const types = ['Plastic','Metal','Glass','Organic','Paper','E-waste'];
  const waste = types[Math.floor(Math.random()*types.length)];
  const kg = Math.round((Math.random()*4 + 0.5)*10)/10;
  const meta = read(META); const amount = Math.round((kg * meta.rate_per_kg)*100)/100;
  const arr = read(WASTE); const id = 'W'+Date.now();
  arr.push({ id, user_id:tgId, waste, kg, amount, detected:true, created_at:new Date().toISOString() });
  write(WASTE, arr);
  let user = findUserByTelegram(tgId); user.total_kg = (user.total_kg||0) + kg; user.balance = (user.balance||0) + amount; user.rank = computeRank(user.total_kg); saveOrUpdateUser(user);
  waitingForWaste[tgId] = false;
  await ctx.reply(`Detected: ${waste} — ${kg} kg. You earned ₦${amount}. Your new balance: ₦${user.balance.toFixed(2)}. (Rank: ${user.rank})`);
});
# rest of file omitted for brevity in this cell

// continue bot.js: remaining handlers and admin commands
// handle text when expecting waste or other flows
bot.on('text', async (ctx, next)=>{
  const tgId = ctx.from.id; const txt = ctx.message.text.trim();
  // waste flow
  if(waitingForWaste[tgId]){
    const lowered = txt.toLowerCase();
    if(lowered === 'estimate'){
      const arr = read(WASTE); const id = 'W'+Date.now();
      arr.push({ id, user_id:tgId, waste:'ToEstimate', kg:0, amount:0, detected:false, status:'awaiting_collection', created_at:new Date().toISOString() });
      write(WASTE, arr);
      waitingForWaste[tgId] = false;
      return ctx.reply(`Pickup request recorded. A collector will estimate weight on collection. ID: ${id}`);
    }
    const kgMatch = txt.match(/([0-9]+(\.[0-9]+)?)/);
    let kg = 0;
    if(kgMatch) kg = parseFloat(kgMatch[1]);
    const types = ['plastic','metal','glass','organic','paper','e-waste','ewaste','electronics'];
    let wasteType = 'General';
    for(const t of types) if(txt.toLowerCase().includes(t)) { wasteType = t.charAt(0).toUpperCase() + t.slice(1); break; }
    if(kg <= 0){ kg = Math.round((Math.random()*3 + 0.5)*10)/10; }
    const meta = read(META); const amount = Math.round((kg * meta.rate_per_kg)*100)/100;
    const arr = read(WASTE); const id = 'W'+Date.now();
    arr.push({ id, user_id:tgId, waste:wasteType, kg, amount, detected:false, created_at:new Date().toISOString() });
    write(WASTE, arr);
    let user = findUserByTelegram(tgId); user.total_kg = (user.total_kg||0) + kg; user.balance = (user.balance||0) + amount; user.rank = computeRank(user.total_kg); saveOrUpdateUser(user);
    waitingForWaste[tgId] = false;
    return ctx.reply(`Recorded: ${wasteType} — ${kg} kg. You earned ₦${amount}. New balance: ₦${user.balance.toFixed(2)} (Rank: ${user.rank})`);
  }
  // withdraw bank details flow
  if(waitingForWithdrawBank[tgId]){
    const parts = txt.split(','); if(parts.length < 2) return ctx.reply('Please provide "Bank Name, AccountNumber"');
    const bank = parts[0].trim(); const acct = parts[1].replace(/\s+/g,'').trim();
    const details = waitingForWithdrawBank[tgId]; waitingForWithdrawBank[tgId] = null;
    const arr = read(WITHD); const id = 'WD'+Date.now();
    arr.push({ id, user_id:tgId, amount: details.amount, bank, account:acct, status:'pending', requested_at:new Date().toISOString() });
    write(WITHD, arr);
    return ctx.reply('Withdrawal request created and pending admin approval. ID: ' + id);
  }
  // complaint flow
  if(waitingForComplaint[tgId]){
    const arr = read(COMPS); const id = 'C'+Date.now(); arr.push({ id, user_id:tgId, text:txt, status:'new', created_at:new Date().toISOString() }); write(COMPS, arr);
    waitingForComplaint[tgId] = false; return ctx.reply('Complaint recorded. Thank you.');
  }
  return next();
});
// My Earnings
bot.hears(/My Earnings/i, ctx=>{
  const user = findUserByTelegram(ctx.from.id); if(!user) return ctx.reply('No profile. /start'); return ctx.reply(`Total kg: ${user.total_kg}\nBalance: ₦${(user.balance||0).toFixed(2)}\nRank: ${user.rank}`);
});
// History: show last 5 waste records
bot.hears(/History/i, ctx=>{
  const arr = read(WASTE).filter(w=>w.user_id===ctx.from.id).slice(-5).reverse();
  if(!arr.length) return ctx.reply('No history.');
  const lines = arr.map(a=>`${a.id} — ${a.waste} — ${a.kg}kg — ₦${(a.amount||0).toFixed(2)} — ${a.created_at}`);
  ctx.reply(lines.join('\n'));
});
// Withdraw: calculate available and ask bank details
bot.hears(/Withdraw/i, ctx=>{
  const user = findUserByTelegram(ctx.from.id); if(!user) return ctx.reply('Verify first.');
  const approvedPaid = read(WITHD).filter(w=>w.user_id===ctx.from.id && w.status==='approved').reduce((s,w)=>s+w.amount,0);
  const available = Math.max(0, (user.balance||0) - approvedPaid);
  if(available <= 0) return ctx.reply('No available balance now.');
  waitingForWithdrawBank[ctx.from.id] = { amount: Math.round(available*100)/100 };
  return ctx.reply(`You can withdraw ₦${available.toFixed(2)}. Send bank details as "BankName, AccountNumber".`);
});
// File Complaint
bot.hears(/File Complaint/i, ctx=>{ waitingForComplaint[ctx.from.id]=true; ctx.reply('Type your complaint now (include State / LGA if available).'); });
// Admin commands guard
function adminOnly(ctx){ if(ctx.from.id !== ADMIN) { ctx.reply('Unauthorized - admin only'); return false; } return true; }
// Admin: set rate
bot.command('setrate', ctx=>{ if(!adminOnly(ctx)) return; const parts = ctx.message.text.split(' ').slice(1); if(!parts.length) return ctx.reply('Usage: /setrate <amount>'); const amt = parseFloat(parts[0]); if(isNaN(amt)) return ctx.reply('Invalid amount'); const meta = read(META); meta.rate_per_kg = amt; write(META, meta); ctx.reply('Rate set to ₦'+amt); });
// view users
bot.command('users', ctx=>{ if(!adminOnly(ctx)) return; const users = read(USERS); if(!users.length) return ctx.reply('No users'); const lines = users.map(u=>`${u.telegram_id} — ${u.first_name||''} — ${u.phone||'no phone'} — ₦${(u.balance||0).toFixed(2)} — kg:${u.total_kg}`); ctx.reply(lines.join('\n')); });
// withdrawals list
bot.command('withdrawals', ctx=>{ if(!adminOnly(ctx)) return; const arr = read(WITHD); if(!arr.length) return ctx.reply('No withdrawals'); const lines = arr.map(w=>`${w.id} — user:${w.user_id} — ₦${w.amount} — ${w.status}`); ctx.reply(lines.join('\n')); });
// approve withdrawal
bot.command('approve', ctx=>{ if(!adminOnly(ctx)) return; const parts = ctx.message.text.split(' ').slice(1); if(!parts.length) return ctx.reply('Usage: /approve <withdrawal_id>'); const id = parts[0]; const arr = read(WITHD); const i = arr.findIndex(x=>x.id===id); if(i===-1) return ctx.reply('Not found'); arr[i].status='approved'; arr[i].approved_at=new Date().toISOString(); write(WITHD,arr); const user = findUserByTelegram(arr[i].user_id); if(user){ user.balance = Math.max(0, (user.balance||0) - arr[i].amount); saveOrUpdateUser(user); bot.telegram.sendMessage(user.telegram_id, `Your withdrawal ${id} of ₦${arr[i].amount} has been approved and marked paid.`); } ctx.reply('Withdrawal approved.'); });
# broadcast
bot.command('broadcast', async ctx=>{ if(!adminOnly(ctx)) return; const msg = ctx.message.text.split(' ').slice(1).join(' '); if(!msg) return ctx.reply('Usage: /broadcast <message>'); const users = read(USERS); let sent=0; for(const u of users){ try{ await bot.telegram.sendMessage(u.telegram_id, msg); sent++; }catch(e){} } ctx.reply('Broadcast attempted to '+sent+' users.'); });
# listwaste
bot.command('listwaste', ctx=>{ if(!adminOnly(ctx)) return; const arr = read(WASTE); if(!arr.length) return ctx.reply('No waste records'); const lines = arr.map(p=>`${p.id} — user:${p.user_id} — ${p.waste} — ${p.kg}kg — ₦${(p.amount||0).toFixed(2)} — ${p.status||'n/a'}`); ctx.reply(lines.join('\n')); });
# markcollected
bot.command('markcollected', ctx=>{ if(!adminOnly(ctx)) return; const parts = ctx.message.text.split(' ').slice(1); if(!parts.length) return ctx.reply('Usage: /markcollected <waste_id> [actual_kg]'); const id = parts[0]; const arr = read(WASTE); const i = arr.findIndex(x=>x.id===id); if(i===-1) return ctx.reply('Not found'); let actual = arr[i].kg || 0; if(parts[1]){ const p = parseFloat(parts[1]); if(!isNaN(p)) actual = p; } arr[i].status='collected'; arr[i].actual_kg = actual; arr[i].collected_at=new Date().toISOString(); write(WASTE,arr); const user = findUserByTelegram(arr[i].user_id); const meta = read(META); user.total_kg = (user.total_kg||0) + actual; const amt = Math.round(actual * meta.rate_per_kg * 100)/100; user.balance = (user.balance||0) + amt; user.rank = computeRank(user.total_kg); saveOrUpdateUser(user); bot.telegram.sendMessage(user.telegram_id, `Your pickup ${id} was collected. You earned ₦${amt} (kg:${actual}).`); ctx.reply(`Marked collected and credited user ₦${amt}`); });
# totalstats
bot.command('totalstats', ctx=>{ if(!adminOnly(ctx)) return; const users = read(USERS); const totalKg = users.reduce((s,u)=>(s+(u.total_kg||0)),0); const totalPayout = users.reduce((s,u)=>(s+(u.balance||0)),0); ctx.reply(`Users: ${users.length}\nTotal kg: ${totalKg}\nTotal balance (sim): ₦${totalPayout.toFixed(2)}`); });
# setadmin
bot.command('setadmin', ctx=>{ if(!adminOnly(ctx)) return; const parts = ctx.message.text.split(' ').slice(1); if(!parts.length) return ctx.reply('Usage: /setadmin <telegram_id>'); const id = Number(parts[0]); if(!id) return ctx.reply('Invalid id'); const meta = read(META); meta.admins = meta.admins||[]; if(!meta.admins.includes(id)) meta.admins.push(id); write(META,meta); ctx.reply('Added admin: '+id); });
# referral helper
bot.command('ref', ctx=>{ ctx.reply('Share: https://t.me/CleanNaijaBot'); });
// computeRank
function computeRank(totalKg){ if(totalKg >= 500) return 'Eco-Champion'; if(totalKg >= 200) return 'Recycler-Hero'; if(totalKg >= 50) return 'Eco-Warrior'; if(totalKg >= 10) return 'Starter Recycler'; return 'Newbie'; }
// launch
bot.launch().then(()=> console.log('CleanNaijaBot running. Admin:', ADMIN)).catch(e=>console.error('Launch error', e));
process.once('SIGINT', ()=> bot.stop('SIGINT')); process.once('SIGTERM', ()=> bot.stop('SIGTERM'));
